export interface PortfolioItem {
    id: number;
    title: string;
    image: string;
    link: string;
  }
  
  export const portfolioItems: PortfolioItem[] = [
    {
      id: 1,
      title: "Preview 1 - Code-Switcher",
      image: "/src/assets/photos/Code_Switcher.png",
      link: "https://code-switcher-two.vercel.app/",
    },
    {
      id: 2,
      title: "Preview 2 - Apple UI Mock",
      image: "/src/assets/photos/Apple_Mock.png",
      link: "https://apple-ui-coral.vercel.app/",
    },
    {
      id: 3,
      title: "Preview 3 - This Website!",
      image: "/src/assets/photos/this.webp",
      link: "",
      },
      {
        id: 4,
        title: "Preview 4- More To Come!!",
        image: "/src/assets/photos/sustain.jpg",
        link: "",
      },
    // Add more as needed
  ];